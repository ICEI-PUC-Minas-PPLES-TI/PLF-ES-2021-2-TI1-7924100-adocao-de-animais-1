


function leDados() {
    let strDados = localStorage.getItem('db_cadastros');
    let objDados = {};
    if (strDados) {
        objDados = JSON.parse(strDados);
    }
    else {
        objDados = {
            cadastros: [
                { nome: "Eric", nomecompleto: "Eric Jardim", email: "ericjardim007gmail.com", senha: "teste1234", telefone: "+55 31 998100509", endereco: "belo horizonte"}
            ]
        }
    }
    return objDados;
}
function salvaDados(dados) {
    localStorage.setItem('db_cadastros', JSON.stringify(dados))
}
function incluirCadastro() {
if (document.getElementById('inputNome').value != '' && document.getElementById('inputNomecomp').value != '' && document.getElementById('inputEmail').value!='' && document.getElementById('inputSenha').value != '' &&  document.getElementById('inputSenha').value == document.getElementById('inputSenha2').value && document.getElementById('inputTel').value != '' && document.getElementById('inputEnd').value != '' ){
    alert('Cadastro realizado com sucesso!');
    //ler dados ls
    let objDados = leDados();


    


    //incluir 
    let strNome = document.getElementById('inputNome').value;
    let strNomecomp = document.getElementById('inputNomecomp').value;
    let strEmail = document.getElementById('inputEmail').value;
    let strSenha = document.getElementById('inputSenha').value;
    let strTel = document.getElementById('inputTel').value;
    let strEnd = document.getElementById('inputEnd').value;
    let novoCadastro = {
        nome: strNome,
        nomecompleto: strNomecomp,
        email: strEmail,
        senha: strSenha,
        telefone: strTel,
        endereco: strEnd,
    };
    objDados.cadastros.push(novoCadastro);

    //salvar no ls
    salvaDados(objDados);
    //redirecionar para o login
    window.location.replace("login_usuario.html");
}
else {
    alert('Por favor preencha todos os campos corretamente')
}



}




//botoes

document.getElementById('btnFin').addEventListener('click', incluirCadastro);






