//botões
let btnDogs = document.querySelector('#btnDogs');
let btnCats = document.querySelector('#btnCats');
let btnBirds = document.querySelector('#btnBirds');
let btnReps = document.querySelector('#btnReps');
//conteúdo de texto
let content = document.querySelector('#content');

//ação onclick
btnDogs.addEventListener('click', () => {
    content.innerHTML = `<h1>Cachorros</h1><p>&nbsp&nbsp&nbsp&nbspEles são charmosos, inteligentes, companheiros, leais e capazes de oferecer um amor 
    incondicional. Não é à toa que todo mundo já se pegou falando: “quero adotar um cachorro como animal de estimação". 
    Embora cães adotados tenham um potencial enorme para trazer muita felicidade, aqui vão algumas questões importantes. 
    Considere-as antes de você tomar essa decisão:<br><br>1- Antes de levar um cachorro para casa, considere se ele não terá de ficar sozinho o tempo todo. 
    Pense também se você está disposto a passear com ele e a oferecer uma vida saudável e feliz.<br><br>2- Cães saudáveis precisam de boa ração, banhos e tosas 
    regulares, vermífugos e vacinação em dia. Tudo isso deve entrar na conta antes da adoção!<br><br>3- Por maior que seja seu amor por seu novo amigo, nem sempre 
    ele se reflete no tamanho do apartamento.<br><br>4- Assim que adotar um cachorro, procure levá-lo o quanto antes a um veterinário para um check-up de saúde. 
    Também é importante garantir, logo no primeiro dia, os itens necessários para que ele se sinta em casa.</p>`;
});
btnCats.addEventListener('click', () => {
    content.innerHTML = `<h1>Gatos</h1><p>&nbsp&nbsp&nbsp&nbspO ato de adotar gato é sinônimo de ter companhia e muitas alegrias em casa. Os felinos 
    domésticos são conhecidos como animais independentes, que conseguem se divertir sozinhos. Por isso, são a escolha de muitas 
    famílias que não ficam tanto tempo em casa.<br><br>1- Antes de qualquer coisa, é importante deixar o local seguro, por isso, instale telas em todas 
    as janelas do seu apartamento. Em casas, verifique todas as rotas de fuga e coloque telas nos locais onde o gato poderia sair. Os gatos 
    domésticos não devem ter acesso à rua, pois ficam suscetíveis à diversas doenças, aos maus-tratos e à acidentes.<br><br>2- Os gatos, Além de exigirem menos 
    atenção, também dão menos trabalho. Mas isso não quer dizer que não se sintam sozinhos, desestimulados e até depressivos se deixados com 
    pouca atenção.</p>`;
});
btnBirds.addEventListener('click', () => {
    content.innerHTML = `<h1>Aves</h1><p>&nbsp&nbsp&nbsp&nbspAs aves são animais belíssimos e que alegram o nosso dia com o seu canto. 
    Antes de adotar uma, você deve conhecer perfeitamente as suas necessidades, mas também é conveniente saber quais são os “contras” de ter 
    uma ave para não acabar arrependido.<br><br>1- Em primeiro lugar é necessário esclarecer que muitas aves não são animais domésticos, e algumas 
    nunca se acostumam nem desfrutam da companhia das pessoas.<br><br>2- Os pássaros são muito sensíveis às impurezas no ar. Eles inspiram grande 
    quantidade de ar em relação ao peso, por tanto absorvem qualquer contaminante que se encontra em suspensão. É muito importante não fumar, 
    não usar incensos nem desodorizantes ou limpadores em aerossol no ambiente onde se encontra a gaiola.<br><br>3- Terá que estar disposto a dedicar 
    muito tempo ao seu novo animal de estimação. Não só levará tempo amestrá-lo e ganhar a sua confiança, mas também limpar a sua jaula, pratos e arredores. 
    Uma boa higiene é indispensável para que a sua ave se mantenha saudável. Há muitos produtos especiais que não liberam tóxicos.</p>`;
});
btnReps.addEventListener('click', () => {
    content.innerHTML = `<h1>Répteis</h1><p>&nbsp&nbsp&nbsp&nbspAo contrário dos animais de estimação comuns, os cuidados com répteis são 
    muito específicos. Contudo, eles têm sido cada vez mais frequentes na casa da maioria dos brasileiros.<br><br>1- Se você está buscando por 
    pets receptivos, talvez os répteis de estimação não sejam os mais indicados. Eles não estarão a todo momento ao seu lado, não pedirão 
    por carinho ou mesmo poderão passear com você no parque.<br><br>2- Para que você possa ter répteis de estimação em sua casa, é imprescindível 
    que você os adote de forma legalizada. Por isso, para comprovar que seu pet nasceu em um cativeiro registrado pelo IBAMA e não foi 
    retirado da natureza, você deve exigir sempre a Nota Fiscal.</p>`;
});